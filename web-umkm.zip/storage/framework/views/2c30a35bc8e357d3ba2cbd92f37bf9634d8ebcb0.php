

<?php $__env->startSection('content'); ?>
    <main id="main">
        <section id="breadcrumbs" class="breadcrumbs">
            <div class="container">

                <ol>
                    <li><a href="index.html">Home</a></li>
                    <li>Inner Page</li>
                </ol>
                <h2>Search</h2>
                <?php echo $__env->make('components.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <section id="card-um" class="card-um">
                    <ul id="card-um-flters" class="d-flex justify-content-center" data-aos="fade-up" data-aos-delay="100">
                        <li data-filter="*" class="filter-active">All</li>
                        <li data-filter=".filter-umkm">UMKM</li>
                        <li data-filter=".filter-koperasi">KOPERASI</li>
                    </ul>
                    <?php if($umkms->count()): ?>
                        <div class="row card-um-container" data-aos="fade-up" data-aos-delay="200">
                            <?php $__currentLoopData = $umkms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $umkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div
                                    class="col-xl-3 col-6 c0 card-um-item filter-app <?php if($umkm->category->category == 'UMKM'): ?> , filter-umkm <?php else: ?> filter-koperasi <?php endif; ?>">
                                    <div class="card-um-img"><img src="/img/portfolio/portfolio-2.jpg" class="img-fluid"
                                            alt="">
                                    </div>
                                    <div class="card-um-info">
                                        <h4><?php echo e($umkm->name); ?></h4>
                                        <p><?php echo e($umkm->category->category); ?></p>
                                        <a href="/img/portfolio/portfolio-1.jpg" data-gallery="portfolioGallery"
                                            class="card-um-lightbox preview-link" title="<?php echo e($umkm->description); ?>"><i
                                                class="bx bx-plus"></i></a>
                                        <a href="/umkm/<?php echo e($umkm->slug); ?>" class="details-link" title="More Details"><i
                                                class="bx bx-link"></i></a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <h1 class="text-center">Not Found :(</h1>
                    <?php endif; ?>
                </section>
                <div class="d-flex justify-content-center pt-3">
                    <?php echo e($umkms->links('components.paginator')); ?>

                </div>
        </section>


    </main><!-- End #main -->


    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webx\web-umkm\resources\views/pages/search.blade.php ENDPATH**/ ?>