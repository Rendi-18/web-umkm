

<?php $__env->startSection('content'); ?>
    <main id="main">
        <section id="breadcrumbs" class="breadcrumbs">
            <div class="container">

                <ol>
                    <li><a href="index.html">Home</a></li>
                    <li>Inner Page</li>
                </ol>
                <h2>Search</h2>
                <div id="search-p">
                    <?php echo $__env->make('components.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div id="card-um" class="card-um">
                    <?php if($koperasis->count()): ?>
                        <div class="row card-um-container" data-aos="fade-up" data-aos-delay="200">
                            <?php $__currentLoopData = $koperasis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $koperasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-xl-3 col-6 c0 card-um-item filter-app">
                                    <div class="card-um-img"><img src="/img/portfolio/portfolio-2.jpg" class="img-fluid"
                                            alt="">
                                    </div>
                                    <div class="card-um-info">
                                        <h4><?php echo e($koperasi->name); ?></h4>
                                        <a href="/img/portfolio/portfolio-1.jpg" data-gallery="portfolioGallery"
                                            class="card-um-lightbox preview-link" title="<?php echo e($koperasi->description); ?>"><i
                                                class="bx bx-plus"></i></a>
                                        <a href="/koperasi/<?php echo e($koperasi->slug); ?>" class="details-link"
                                            title="More Details"><i class="bx bx-link"></i></a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <h1 class="text-center">Not Found :(</h1>
                    <?php endif; ?>
                </div>
                <div class="d-flex justify-content-center pt-3">
                    <?php echo e($koperasis->links('components.paginator')); ?>

                </div>
        </section>


    </main><!-- End #main -->


    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webx\web-umkm\resources\views/pages/search/koperasi.blade.php ENDPATH**/ ?>