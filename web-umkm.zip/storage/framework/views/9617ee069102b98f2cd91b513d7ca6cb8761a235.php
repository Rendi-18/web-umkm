<section id="regist-koperasi">
    <div class="col-12 mb-5">
        <h4 class="col-6 fw-bold py-3 mb-2"><span class="text-muted fw-light">Data/</span> Pengajuan Bantuan</h4>

        
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <h5 class="card-header">Tabel Pengajuan Bantuan</h5>
            <form action="/dashboard/izin/surat" method="get" class="d-flex mx-4 mb-2">
                <input class="form-control me-2" type="text" name="search" id="search" placeholder="Search"
                    aria-label="Search" value="<?php echo e(request('search')); ?>">
                <button class="btn btn-outline-primary" type="submit">Search</button>
            </form>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>NIB</th>
                            <th>Nama UMKM</th>
                            <th>Phone No</th>
                            <th>Jenis Bantuan</th>
                            <th>Deskripsi</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php if($bantuans->count()): ?>
                            <?php $__currentLoopData = $bantuans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bantuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><strong><?php echo e($bantuan->umkm->nib); ?></strong></td>
                                    <td><?php echo e($bantuan->umkm->name); ?></td>
                                    <td><?php echo e($bantuan->phonenumber); ?></td>
                                    <td>
                                        <span class="badge bg-label-primary me-1">
                                            <strong><?php echo e($bantuan->bantuan); ?></strong>
                                        </span>
                                    </td>
                                    <td><?php echo Str::Limit($bantuan->description, 15); ?></td>
                                    <td>
                                        <?php if($bantuan->status == 0): ?>
                                            <div class="spinner-border spinner-border-sm text-warning" role="status">
                                                <span class="visually-hidden">Loading...</span>
                                            </div><span class="ms-2 badge bg-label-warning me-1">Pending</span>
                                        <?php elseif($bantuan->status == 1): ?>
                                            <span class="text-info"><strong><i
                                                        class="bx bx-check me-1"></i></strong></span>
                                            <span class="badge bg-label-info me-1">Aproved</span>
                                        <?php else: ?>
                                            <span class="text-danger"><strong>
                                                    <i class="bx bx-x me-1"></i></strong></span>
                                            <span class="badge bg-label-danger me-1">Ditolak</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                                data-bs-toggle="dropdown">
                                                <i class="bx bx-dots-vertical-rounded"></i>
                                            </button>
                                            <div class="dropdown-menu">
                                                <button type="button" class="dropdown-item" data-bs-toggle="modal"
                                                    data-bs-target="#backDropModal">
                                                    <i class="bx bx-check me-1"></i>Aprove
                                                </button>

                                                <form id="userDelete-form dropdown-item"
                                                    action="/dashboard/pengajuan/<?php echo e($bantuan->id); ?>/bantuan"
                                                    method="post">
                                                    <?php echo method_field('put'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="status" value="2">
                                                    <button class="dropdown-item"
                                                        onclick="return confirm('Apa anda yakin?')">
                                                        <i class="bx bx-x me-1"></i> Tolak
                                                    </button>
                                                </form>
                                                <?php if($bantuan->file): ?>
                                                    <a class="dropdown-item" target="_blank"
                                                        href="<?php echo e(asset('storage/' . $bantuan->file)); ?>" download><i
                                                            class='bx bx-down-arrow-circle'></i>
                                                        Download
                                                    </a>
                                                <?php endif; ?>

                                            </div>
                                        </div>
                                        <?php echo $__env->make('dashboard.components.modalsformBantuan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <h1 class="text-center mt-5 mb-5">Bantuan not found :)</h1>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php /**PATH D:\webx\web-umkm\resources\views/dashboard/pages/pengajuan/pengajuanbantuan.blade.php ENDPATH**/ ?>