
<?php $__env->startSection('content'); ?>
    <main id="main">
        <section id="breadcrumbs" class="breadcrumbs">
            <div class="container">
                <ol>
                    <li><a href="/">Home</a></li>
                    <li>Pegawai</li>
                </ol>
                <h2>Data Pegawai Dinas Koperasi UMKM Lampung</h2>

                <section id="employee" class="employee  py-0">
                    <div class="container" data-aos="fade-up">
                        <div class="row">
                            <?php $__currentLoopData = $pegawais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-6 my-lg-2 my-1 px-2">
                                    <div class="member align-items-start p-2 p-lg-4 d-flex" data-aos="zoom-in"
                                        data-aos-delay="100">
                                        <div class="col-4 d-flex">
                                            <div class="m-auto pic">
                                                <?php if($pegawai->image): ?>
                                                    <img src="<?php echo e(asset('storage/' . $pegawai->image)); ?>" class="img-fluid"
                                                        alt="">
                                                <?php else: ?>
                                                    <img src="img\temp\user-temp.png" class="img-fluid" alt="">
                                                <?php endif; ?>
                                            </div>

                                        </div>
                                        <div class="col-6 ps-lg-2 member-info">
                                            <h5><?php echo e($pegawai->name); ?></h5>
                                            <p><?php echo e($pegawai->classification); ?></p>
                                            <span><?php echo e($pegawai->position); ?></span>
                                            <p><?php echo e($pegawai->description); ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="d-flex justify-content-center pt-3">
                        <?php echo e($pegawais->links('components.paginator')); ?>

                    </div>
                </section>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webx\web-umkm\resources\views/pages/pegawai/index.blade.php ENDPATH**/ ?>