<?php echo e($slot); ?>

<?php /**PATH D:\webx\web-umkm\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>