<!-- ======= card-um Section ======= -->
<section id="card-um" class="card-um">
    <div class="container" data-aos="fade-up">
        <div class="section-title p-0">
            <h2>UMKM</h2>
        </div>
        <div id="search" class="row-content py-3">
            <div class="row justify-content-center">
                <div class="col-lg-8 row">
                    <p class="text-center">Temukan Unit UMKM Di sekitar anda</p>
                    <div id="input-g">
                        <form action="/search/umkm" method="get" id="formSearch" class="row p-0 input-group">
                            <input type="text" class="col-10 form-control shad-none" name="search"
                                value="<?php echo e(request('search')); ?>">
                            <button class="col-2 form-control shad-none" type="submit">
                                <i class="bx bx-search"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row card-um-container" data-aos="fade-up" data-aos-delay="200">
            <?php $__currentLoopData = $umkms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $umkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-6 card-um-item filter-umkm">
                    <div class="card-um-img shadow-sm">
                        <?php if($umkm->image): ?>
                            <img src="<?php echo e(asset('storage/' . $umkm->image)); ?>" alt="user-avatar" class="img-fluid">
                        <?php else: ?>
                            <img src="/img/temp/store-temp.png" alt="user-avatar" class="img-fluid">
                        <?php endif; ?>
                    </div>

                    <div class="card-um-info">
                        <h4><?php echo e(Str::limit($umkm->name, 15)); ?></h4>
                        <?php if($umkm->image): ?>
                            <a href="<?php echo e(asset('storage/' . $umkm->image)); ?>" data-gallery="portfolioGallery"
                                class="card-um-lightbox preview-link" title="<?php echo e($umkm->description); ?>"><i
                                    class="bx bx-detail"></i></a>
                        <?php else: ?>
                            <a href="/img/temp/store-temp.png" data-gallery="portfolioGallery"
                                class="card-um-lightbox preview-link" title="<?php echo e($umkm->description); ?>"><i
                                    class="bx bx-detail"></i></a>
                        <?php endif; ?>
                        <a href="/umkm/<?php echo e($umkm->slug); ?>" class="details-link" title="More Details"><i
                                class="bx bx-link"></i></a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- End Portfolio Section -->
<?php /**PATH D:\webx\web-umkm\resources\views/components/umkm.blade.php ENDPATH**/ ?>