<!-- ======= Footer Section ======= -->
<footer id="footer"
    class="<?php echo e(Request::is('umkm/product*') ? 'fixed-lg-bottom' : ''); ?><?php echo e(Request::is('search*') ? 'fixed-lg-bottom' : ''); ?><?php echo e(Request::is('agenda*') ? 'fixed-lg-bottom' : ''); ?>">
    <div class="container footer-bottom clearfix">
        <div class="copyright"> © Copyright <strong><span><?php echo e($website[0]->sitename); ?></span></strong>. All Rights
            Reserved
        </div>
        
    </div>
</footer>
<!-- End Footer -->
<?php /**PATH D:\webx\web-umkm\resources\views/components/footer.blade.php ENDPATH**/ ?>