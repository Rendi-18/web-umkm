
<?php $__env->startSection('content'); ?>
    <!-- Content wrapper -->
    <div class="content-wrapper ">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">
            <div id="dana">
                <section id="regist-koperasi">
                    <h4 class="col-6 fw-bold pb-2 mb-2">Pengajuan Bantuan</h4>

                    
                    <?php if(session()->has('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <div class="row g-4 mb-3">
                        <div class="col-lg-12">
                            <div class="row">
                                <div class="col-lg">
                                    <div class="card">
                                        <h5 class="card-header">Form Pengajuan Bantuan</h5>
                                        <div class="card-body">
                                            <form class="" action="/dashboard/bantuan/<?php echo e($bantuan->id); ?>"
                                                method="POST" enctype="multipart/form-data">
                                                <?php echo method_field('put'); ?>
                                                <?php echo csrf_field(); ?>
                                                
                                                <div class="row mb-3">
                                                    <label class="col-sm-2 col-form-label" for="name">Nama
                                                        UMKM / NIB</label>
                                                    <div class="col-sm-10">
                                                        <div class="input-group input-group-merge">
                                                            <span class="input-group-text "><i
                                                                    class="bx bx-store-alt"></i></span>
                                                            
                                                            <select class="form-select" id="umkm_id" name="umkm_id">
                                                                <?php $__currentLoopData = $umkms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $umkm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if(old('umkm_id', $bantuan->umkm_id) == $umkm->id): ?>
                                                                        <option value="<?php echo e($umkm->id); ?>" selected>
                                                                            <?php echo e($umkm->name); ?>

                                                                            / (<?php echo e($umkm->nib); ?>)
                                                                        </option>
                                                                    <?php else: ?>
                                                                        <option value="<?php echo e($umkm->id); ?>">
                                                                            <?php echo e($umkm->name); ?>

                                                                            / (<?php echo e($umkm->nib); ?>)</option>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </select>
                                                            <?php $__errorArgs = ['name-nib'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>

                                                
                                                <div class="row mb-3">
                                                    <label class="col-sm-2 col-form-label" for="phonenumber">Phone
                                                        No</label>
                                                    <div class="col-sm-10">
                                                        <div class="input-group input-group-merge">
                                                            <span id="basic-icon-default-phone2" class="input-group-text"><i
                                                                    class="bx bx-phone"></i></span>
                                                            <input type="number" name="phonenumber" id="phonenumber"
                                                                class="form-control phone-mask <?php $__errorArgs = ['phonenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                placeholder="+62" aria-label="658 799 8941"
                                                                aria-describedby="basic-icon-default-phone2"
                                                                value="<?php echo e(old('phonenumber', $bantuan->phonenumber)); ?>"
                                                                required>
                                                            <?php $__errorArgs = ['phonenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>

                                                
                                                <div class="row mb-3">
                                                    <label class="col-sm-2 col-form-label" for="bantuan">Jenis
                                                        Bantuan</label>
                                                    <div class="col-sm-10">
                                                        <div class="input-group input-group-merge">
                                                            <span id="basic-icon-default-phone2" class="input-group-text"><i
                                                                    class="bx bx-copy-alt"></i></span>
                                                            <input type="text" name="bantuan" id="bantuan"
                                                                class="form-control phone-mask <?php $__errorArgs = ['bantuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                placeholder="Jenis Bantuan.."
                                                                value="<?php echo e(old('bantuan', $bantuan->bantuan)); ?>" required>
                                                            <?php $__errorArgs = ['bantuan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>

                                                
                                                <div class="row mb-3">
                                                    <label class="col-sm-2 col-form-label" for="image">Proposal</label>
                                                    <div
                                                        class="col-sm-10 d-flex align-items-start align-items-sm-center gap-4 ">
                                                        <div class="input-group">
                                                            <input type="hidden" name="oldDoc"
                                                                value="<?php echo e($bantuan->file); ?>">
                                                            <input type="file"
                                                                class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                id="file"accept=".pdf" name="file" required>
                                                            <label class="input-group-text" for="file">Upload</label>
                                                            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>

                                                
                                                <div class="row mb-3">
                                                    <label class="col-sm-2 col-form-label"
                                                        for="description">Deskripsi</label>
                                                    <div class="col-sm-10">
                                                        <div class="input-group input-group-merge flex-column">
                                                            <input type="hidden" name="description" id="description"
                                                                class="form-control phone-mask <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                                placeholder="Tulis disini deskripsi yang anda butuhkan"
                                                                aria-describedby="basic-icon-default-address"
                                                                value="<?php echo e(old('description', $bantuan->description)); ?>"
                                                                required>
                                                            <trix-editor input="description"></trix-editor>
                                                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                                <div class="invalid-feedback">
                                                                    <?php echo e($message); ?>

                                                                </div>
                                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                        </div>
                                                    </div>
                                                </div>


                                                <div class="row justify-content-end">
                                                    <div class="col-sm-10">
                                                        <button type="submit" class="btn btn-primary"><span
                                                                class='bx bx-mail-send'></span>
                                                            &nbsp;
                                                            Send</button>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>

        
        <?php echo $__env->make('dashboard.components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="content-backdrop fade"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\webx\web-umkm\resources\views/dashboard/pages/bantuan/edit.blade.php ENDPATH**/ ?>