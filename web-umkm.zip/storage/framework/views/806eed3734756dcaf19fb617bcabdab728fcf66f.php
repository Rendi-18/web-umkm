<!-- Modal -->
<div class="modal fade" id="exampleModal<?php echo e($product->id); ?>" tabindex="-1"
    aria-labelledby="exampleModalLabel<?php echo e($product->id); ?>" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered ">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel<?php echo e($product->id); ?>"><?php echo e($product->name); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-4">
                        <?php if($product->image): ?>
                            <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="user-avatar" class="img-fluid"
                                id="uploadedAvatar">
                        <?php else: ?>
                            <img src="/img/temp/product-temp.png" alt="user-avatar" class="img-fluid"
                                id="uploadedAvatar">
                        <?php endif; ?>
                        <span class="col-12 d-flex">
                            <i class="bx bx-money bx-burst my-auto"></i>
                            &nbsp;Harga &nbsp;
                            <span class="my-auto">: Rp. <?php echo number_format($product->price,0,',','.'); ?></span>
                        </span>
                        <span class="col-12 d-flex">
                            <i class='bx bx-cuboid bx-burst my-auto'></i>
                            &nbsp;Berat &nbsp;
                            <span class="my-auto">: <?php echo e($product->weight); ?> Kg</span>
                        </span>
                    </div>
                    <div class="col-8">
                        <span>
                            <p>Deskripsi Produk</p>
                            <?php echo e($product->description); ?>

                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Perspiciatis itaque, velit saepe
                            consectetur rem tempora quia, dicta maiores numquam sed deleniti aliquid porro et? Ducimus
                            nisi
                            assumenda vero. Corporis, quo.
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Non saepe animi itaque nulla
                            accusamus,
                            nisi odio voluptas aspernatur, excepturi commodi, perspiciatis culpa repudiandae praesentium
                            rem
                            quis modi. Mollitia, aut repellendus!
                        </span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php /**PATH D:\webx\web-umkm\resources\views/components/modalProduct.blade.php ENDPATH**/ ?>