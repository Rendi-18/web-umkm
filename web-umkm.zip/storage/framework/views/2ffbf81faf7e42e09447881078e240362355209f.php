<!-- Footer -->
<footer class="content-footer footer bg-footer-theme mt-8">
    <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
            Copyright ©
            <script>
                document.write(new Date().getFullYear());
            </script>
            <a href="/" target="_blank" class="footer-link fw-bolder">🧾 SIBADU</a>
            .All rights reserved.
        </div>
        <div>
            <a href="/#contact" target="_blank" class="footer-link me-4">Contact Us</a>
        </div>
    </div>
</footer>
<!-- / Footer -->
<?php /**PATH D:\webx\web-umkm\resources\views/dashboard/components/footer.blade.php ENDPATH**/ ?>