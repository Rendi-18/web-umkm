<?php if($paginator->hasPages()): ?>
    <nav>
        <ul class="pagination">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                    <span class="page-link border-0 rounded shadow-sm" aria-hidden="true"><i
                            class="bi bi-chevron-double-left"></i> Previous</span>
                </li>
            <?php else: ?>
                <li class="page-item ">
                    <a class="page-link border-0 rounded shadow-sm" href="<?php echo e($paginator->previousPageUrl()); ?>#berita"
                        rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>"><i class="bi bi-chevron-double-left"></i>
                        Previous</a>
                </li>
            <?php endif; ?>



            <select onchange="location = this.value" class="page-link border-0 mx-3 px-2 rounded shadow-sm">
                <?php $__currentLoopData = $paginator->getUrlRange(1, $paginator->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <option selected><?php echo e($page); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($url); ?>">
                            <?php echo e($page); ?>

                        </option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>



            
            <?php if($paginator->hasMorePages()): ?>
                <li class="page-item">
                    <a class="page-link border-0 rounded shadow-sm" href="<?php echo e($paginator->nextPageUrl()); ?>"
                        rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">Next <i
                            class="bi bi-chevron-double-right"></i></a>
                </li>
            <?php else: ?>
                <li class="page-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                    <span class="page-link border-0 rounded shadow-sm" aria-hidden="true">Next <i
                            class="bi bi-chevron-double-right"></i></span>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>
<?php /**PATH D:\webx\web-umkm\resources\views/components/paginator.blade.php ENDPATH**/ ?>