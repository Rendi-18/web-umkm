<section id="cta" class="cta">
    <div class="container aos-init aos-animate" data-aos="zoom-in">
        <div class="row d-flex">
            <div class="col-lg-9 text-center text-lg-start">
                <h3>Daftarkan UMKM anda</h3>
                <p>Mari daftarkan UMKM anda di SIBADU, aku kami membantu pengelolaan serta pengurusasn surat
                    izin yang anda perlukan</p>
            </div>
            <div class="row m-auto">
                <div class="col-lg-3 cta-btn-container text-center"> <a class="cta-btn align-middle"
                        href="/dashboard/register/umkm">Daftar UMKM</a></div>
            </div>

        </div>
    </div>
</section>
<?php /**PATH D:\webx\web-umkm\resources\views/components/regist.blade.php ENDPATH**/ ?>