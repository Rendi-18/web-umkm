<section>
    <div class="col-12">
        <h4 class="col-6 fw-bold py-3 mb-2">Pesan Pengunjung</h4>
        
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo e(session('success')); ?>

                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="card">
            <h5 class="card-header">Tabel Pesan Pengunjung</h5>
            <div class="table-responsive text-nowrap">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Nama Pengunjung</th>
                            <th>Email Pengunjung</th>
                            <th>Subject</th>
                            <th>Pesan</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php if($pesans->count()): ?>
                            <?php $__currentLoopData = $pesans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pesan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($pesan->id); ?></td>
                                    <td><strong><?php echo e($pesan->name); ?></strong></td>
                                    <td><?php echo e($pesan->email); ?></td>
                                    <td><span
                                            class="d-inline-block text-truncate align-middle"><?php echo e($pesan->subject); ?></span>
                                    </td>
                                    <td><span class="d-inline-block text-truncate align-middle">
                                            <?php echo e($pesan->message); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <div class="dropdown">
                                            <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                                data-bs-toggle="dropdown">
                                                <i class="bx bx-dots-vertical-rounded"></i>
                                            </button>
                                            <div class="dropdown-menu">
                                                <form id="mail" action="/dashboard/pesan/<?php echo e($pesan->id); ?>"
                                                    method="post">
                                                    <?php echo method_field('delete'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button class="dropdown-item"
                                                        onclick="return confirm('Apa anda yakin?')">
                                                        <i class="bx bx-trash me-1"></i> Hapus Pesan
                                                    </button>
                                                </form>
                                                <a class="dropdown-item" href="/dashboard/pesan/<?php echo e($pesan->id); ?>">
                                                    <i class="bx bx-envelope me-1"></i> Detail
                                                </a>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <h1 class="text-center mt-5 mb-5">
                                Pesan not found :)
                            </h1>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php /**PATH D:\webx\web-umkm\resources\views/dashboard/pages/pesan/pesan.blade.php ENDPATH**/ ?>